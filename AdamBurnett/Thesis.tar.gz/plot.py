import pylab as pl
import glob

MOUNT = "/home/adam/mount/users/adamh5/logs/"
#Get the most recent Thermistor log
logs = sorted(glob.glob(MOUNT + "Thermistor/*.log"))
recentthermistor = ""
thermistortemp = []
if (len(logs) > 1):
        recentthermistor = logs[len(logs)-2]
else:
	recentthermistor = ""

#Build the thermistor plot
with open(recentthermistor, "r") as ifile:
	thermistortemp = map(float, ifile)

thermistorplot = pl.plot(thermistortemp, 'bo', label='Thermistor')
pl.legend(loc='upper center', bbox_to_anchor=(0.5,-0.1))
pl.axis([0, len(thermistortemp), min(thermistortemp)-.2, max(thermistortemp)+.2])
pl.title('Oven Thermistor Data')
pl.xlabel('Seconds')
pl.ylabel('Temperature (C)')
pl.show()



#testplot, = pl.plot(controlregion, 'bo', label='Test Region')
#controlplot, = pl.plot(testregion, 'ro', label='Control Region')
#legend = pl.legend(loc='upper center', bbox_to_anchor=(0.5,-0.1))
#pl.title('Characterization Results')
#pl.xlabel('Time: Hours')
#pl.ylabel('Percentage Change from Original')
#pl.show()
