#Created by: Adam Burnett
#Email:adam.burnett@byu.edu
import os
import glob
import math
import datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as pl
import numpy as np

#change these when switching machines
THESIS_DIR = "/home/adam/Thesis/"
BOARD = "Burn" 
MOUNT = "/home/adam/mount/users/adamh5/logs/"
#end
error = 0
num_values=7
recentlogpath = max(glob.iglob(THESIS_DIR + 'logs/XMD/*.log'), key=os.path.getctime)
valueslogpath = THESIS_DIR + "logs/values.data"
plotlogpath = THESIS_DIR + "logs/plot.data"
testphrase = "Test Region"
controlphrase = "Control Region"
donephrase = "done."
testnumbers = []
controlnumbers = []
originaltest = 0
originalcontrol = 0
recenttest = 0
recentcontrol = 0
content = []
controldata = []
testdata = []
plotfile = THESIS_DIR + "logs/current.png"
temperature = []
diodefile = THESIS_DIR + "logs/diode.png"
thermistorfile = THESIS_DIR + "logs/thermistor.png"
onetwofile = THESIS_DIR + "logs/1.2V.png"
twofivefile = THESIS_DIR + "logs/2.5V.png"
threethreefile = THESIS_DIR + "logs/3.3V.png"
controllog = THESIS_DIR + "logs/control.log"
testlog = THESIS_DIR + "logs/test.log"
thermistortemp = []
onetwovoltage = []
twofivevoltage = []
threethreevoltage = []

#Get the date of the next to most recent log
logs = sorted(glob.glob(THESIS_DIR + "logs/XMD/*.log"))
if (len(logs) > 1):
        recent = logs[len(logs)-2]
        recentname = recent.split('-')
        recentdate = recentname[1].replace(".","/") + " " + recentname[2].replace(".log","").replace(".",":")

else:
        recentdate = ""

#Get the temperature(Diode) log file from the last hour
temperaturelogs = sorted(glob.glob(MOUNT + "Diode/*.log"))
if (len(temperaturelogs) > 1):
	recenttemperature = temperaturelogs[len(temperaturelogs)-2]
else:
	recenttemperature = ""

#Get the temperature(Thermistor) log file from the last hour
thermistorlogs = sorted(glob.glob(MOUNT + "Thermistor/*.log"))
if (len(thermistorlogs) > 1):
        recentthermistor = thermistorlogs[len(thermistorlogs)-2]
else:
        recentthermistor = ""

#Get the 1.2V Data from the last hour
onetwologs = sorted(glob.glob(MOUNT + BOARD + "-1.2V/*.log"))
if (len(onetwologs) > 1):
        recentonetwo = onetwologs[len(onetwologs)-2]
else:
        recentonetwo = ""

#Get the 2.5V Data from the last hour
twofivelogs = sorted(glob.glob(MOUNT + BOARD + "-2.5V/*.log"))
if (len(onetwologs) > 1):
        recenttwofive = twofivelogs[len(twofivelogs)-2]
else:
        recenttwofive = ""

#Get the 3.3V Data from the last hour
threethreelogs = sorted(glob.glob(MOUNT + BOARD + "-3.3V/*.log"))
if (len(threethreelogs) > 1):
        recentthreethree = threethreelogs[len(threethreelogs)-2]
else:
        recentthreethree = ""


#Remove '^M' characters from the log file
os.system("sed -i 's/^M//' " + recentlogpath)

#find the values and place them in arrays
with open(recentlogpath, "r") as ifile:
	for line in ifile:
		if testphrase in line:
			for i in range(0,num_values):
				line = ifile.next()
				testnumbers.append(int(line))
			ifile.next()
			for i in range(0,num_values):
				line = ifile.next()
				controlnumbers.append(int(line))
ifile.close()

testaverage = 0
controlaverage = 0

#Check if there was an error
if (len(testnumbers) == 0):
	error = 1
else:
	#calculating averages
	testaverage = (sum(testnumbers)/len(testnumbers))
	controlaverage = (sum(controlnumbers)/len(controlnumbers))

#checking if the values file exists (if not, this is the original characterization)
if not os.path.isfile(valueslogpath):
	originaltest = testaverage
	recenttest = testaverage
	originalcontrol = controlaverage
	recentcontrol = controlaverage
else:
	#read original and recent characterization values
	with open(valueslogpath, "rw") as ifile:	
		for line in ifile:
			content.append(int(line))
	originaltest=content[0]
	originalcontrol=content[1]
	recenttest=content[2]
	recentcontrol=content[3]
	ifile.close()

valuesfile = open(valueslogpath, 'w')
valuesfile.truncate()
valuesfile.write(str(originaltest))
valuesfile.write("\n")
valuesfile.write(str(originalcontrol))
valuesfile.write("\n")
valuesfile.write(str(testaverage))
valuesfile.write("\n")
valuesfile.write(str(controlaverage))
valuesfile.write("\n")
valuesfile.close()

#write updated entries to values file
with open(valueslogpath, "rw") as ifile:
	data = ifile.readlines()
ifile.close()

testpercentfromorig = 0
controlpercentfromorig = 0
testpercentfromrec = 0
controlpercentfromrec = 0

if (error == 0):
	#calculate percentages
	testpercentfromorig = 100*(originaltest - testaverage)/float(originaltest)
	controlpercentfromorig = 100*(originalcontrol - controlaverage)/float(originalcontrol)
	testpercentfromrec = 100*(recenttest - testaverage)/float(recenttest)
	controlpercentfromrec = 100*(recentcontrol - controlaverage)/float(recentcontrol)

#Building the plots

#Write data out for plot
with open("logs/control.log", "a+") as ifile:
	ifile.write(str(controlpercentfromorig) + "\n")
with open("logs/test.log", "a+") as ifile:
	ifile.write(str(testpercentfromorig) + "\n")

#Build timing plot
with open(controllog, "r") as ifile:
        controldata = map(float, ifile)

with open(testlog, "r") as ifile:
        testdata = map(float, ifile)

timingaxis = np.linspace(1,len(controldata),len(controldata))

controlcoeff = np.polyfit(timingaxis, controldata, 1)
testcoeff = np.polyfit(timingaxis, testdata, 1)

controlline = []
testline = []

for x in range(0, len(controldata)):
        controlline.append(controlcoeff[0]*timingaxis[x] + controlcoeff[1])
        testline.append(testcoeff[0]*timingaxis[x] + testcoeff[1])

testplot, = pl.plot(testdata, 'bo', label='Test Region')
pl.plot(timingaxis, testline, linestyle='solid', color='blue')
controlplot, = pl.plot(controldata, 'ro', label='Control Region')
pl.plot(timingaxis, controlline, linestyle='solid', color='red')

legend = pl.legend(loc='upper center', bbox_to_anchor=(0.5,-0.1))
pl.axis([1, len(controldata), min(testdata)-.2, max(testdata)+.2])
pl.title('Characterization Results')
pl.xlabel('Time: Hours')
pl.ylabel('Percentage Change from Original')
pl.subplots_adjust(bottom=0.2)
pl.savefig(plotfile)
pl.clf()

#Build temperature(Diode) plot

with open(recenttemperature, "r") as ifile:
	temperature = map(float, ifile)

tempplot = pl.plot(temperature, 'ro', label='Temperature (C)')
legend = pl.legend(loc='upper center', bbox_to_anchor=(0.5,-0.1))
pl.axis([0,(3600/6)-1, 45,47])
pl.title('Temperature')
pl.xlabel('Time (seconds)')
pl.ylabel('Temperature (C)')
pl.savefig(diodefile)

pl.clf()

#Build temperature(Thermistor) plot

with open(recentthermistor, "r") as ifile:
        thermistortemp = map(float, ifile)
thermistorplot = pl.plot(thermistortemp, 'bo', label='Thermistor')
pl.legend(loc='upper center', bbox_to_anchor=(0.5,-0.1))
pl.axis([0, len(thermistortemp), min(thermistortemp)-.2, max(thermistortemp)+.2])
pl.title('Oven Thermistor Data')
pl.xlabel('Seconds')
pl.ylabel('Temperature (C)')
pl.savefig(thermistorfile)

pl.clf()

#Build 1.2V plot
with open(recentonetwo, "r") as ifile:
        onetwovoltage = map(float, ifile)
onetwoplot = pl.plot(onetwovoltage, 'bo', label='1.2V Supply')
pl.legend(loc='upper center', bbox_to_anchor=(0.5,-0.1))
pl.axis([0, len(onetwovoltage), min(onetwovoltage)-.005, max(onetwovoltage)+.005])
pl.title('1.2V Supply')
pl.xlabel('Seconds')
pl.ylabel('Voltage (V)')
pl.savefig(onetwofile)

pl.clf()

#Build 2.5V plot
with open(recenttwofive, "r") as ifile:
        twofivevoltage = map(float, ifile)
twofiveplot = pl.plot(twofivevoltage, 'bo', label='2.5V Supply')
pl.legend(loc='upper center', bbox_to_anchor=(0.5,-0.1))
pl.axis([0, len(twofivevoltage), min(twofivevoltage)-.005, max(twofivevoltage)+.005])
pl.title('2.5V Supply')
pl.xlabel('Seconds')
pl.ylabel('Voltage (V)')
pl.savefig(twofivefile)

pl.clf()

#Build 3.3V plot

with open(recentthreethree, "r") as ifile:
        threethreevoltage = map(float, ifile)
threethreeplot = pl.plot(threethreevoltage, 'bo', label='3.3V Supply')
pl.legend(loc='upper center', bbox_to_anchor=(0.5,-0.1))
pl.axis([0, len(threethreevoltage), min(threethreevoltage)-.005, max(threethreevoltage)+.005])
pl.title('3.3V Supply')
pl.xlabel('Seconds')
pl.ylabel('Voltage (V)')
pl.savefig(threethreefile)

pl.clf()

#Write message to file

message = open("message.txt", 'w')
message.truncate()

message.write("Hi all, \r\n\nHere are the most recent results:\r\nLast characterization previous to this one: " + recentdate + "\r\n\nTest Region\r\n\nCurrent Average: " + str(testaverage) + "\r\nDifference from original characterization: " + str(testpercentfromorig) + "%\r\nDifference from most recent characterization: " + str(testpercentfromrec) + "%\r\n\r\nControl Region \r\n\nCurrent Average: " + str(controlaverage) + "\r\nDifference from original characterization: " + str(controlpercentfromorig) + "%\r\nDifference from most recent characterization: " + str(controlpercentfromrec) + "%\r\n\nI have attached the log files and the current plots for reference.\r\n\nAdam Burnett")

message.close()





			
		

